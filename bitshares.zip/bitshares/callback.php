<?php

require 'functions.php';


postToEcwid($_POST);

?>