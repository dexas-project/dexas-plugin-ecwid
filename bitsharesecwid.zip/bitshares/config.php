<?php
define('ROOT', __DIR__ .DIRECTORY_SEPARATOR);
$relayURL = 'http://app.ecwid.com/authorizenet/6223086';
$baseURL = 'http://bitshares.ecwid.com/';
$accountName = 'opencartdemo';
$rpcUser = 'user';
$rpcPass = 'pass';
$rpcPort = 1234;
$demoMode = TRUE;
$login = 'ecwidbitshares'; // see README
$hashSalt = 'ecwidopencardemo'; // see README
$cronToken = '234343sfsdf23424'; // see README
?>